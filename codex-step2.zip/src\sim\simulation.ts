import { moveWorldOneTick } from "./movement";
import type { SimulationScenario, SimulationState } from "./types";
import { createWorld } from "./world";

export const FIXED_TICKS_PER_SECOND = 20;

export function createSimulation(
  scenario: SimulationScenario,
): SimulationState {
  const initializedWorld = createWorld(scenario);

  return {
    tick: 0,
    rngState: initializedWorld.rngState,
    world: initializedWorld.world,
  };
}

/** Advances the complete simulation by exactly one fixed tick. */
export function advanceSimulationOneTick(simulation: SimulationState): void {
  // Foundation system order: movement with boundary reflection, then tick count.
  moveWorldOneTick(simulation.world);
  simulation.tick += 1;
}
