# Review Doctrine

## Purpose

Use this checklist before accepting Codex changes.

The previous project failed through complexity, bugs, and slow frame rate. Reviews must guard against those failure modes.

## Architecture Review

Check:

```txt
simulation code remains in src/sim
rendering code remains in src/render
worker boundary remains in src/worker
simulation does not import PixiJS
simulation does not import DOM/browser APIs
renderer does not mutate simulation state directly
```

Reject changes that mix simulation rules into rendering code.

## Determinism Review

Check:

```txt
no Math.random() in src/sim
no Date.now() in simulation rules
no frame delta time used for simulation outcomes
same seed replay remains stable
system order remains explicit
Performance Review
```

Check for:

```txt
nested all-entity comparisons
pathfinding every entity every tick
sprite destruction/recreation every frame
large worker messages
temporary object/array creation in hot loops
debug overlays always-on with no disable option
```

If performance-sensitive code changed, require measurement.

## Testing Review

Check:

```txt
new simulation rules have tests
bug fixes have regression tests
determinism tests still pass
performance scenarios still run
typecheck passes
```

Do not accept visual-only validation for simulation rules.

## Scope Review

Prefer small changes.

Be suspicious of changes that touch many layers at once:

```txt
sim + worker + render + UI + content
```

That may be valid, but Codex must explain why.

## Dependency Review

Codex must justify new production dependencies.

Reject dependencies that are added merely for convenience when a small local implementation would be clearer.

## Acceptable First Milestone

The first acceptable milestone is boring:

```txt
1000 moving dots
worker simulation
Pixi rendering
pause/resume
step tick
seeded replay
basic metrics
headless tests
```

Do not accept combat, morale, factions, or complex AI before this foundation works.
